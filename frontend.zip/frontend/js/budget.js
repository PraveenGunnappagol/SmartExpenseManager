let editingBudgetId = null;

const CURRENT_USER_ID =
    Number(localStorage.getItem("userId"));

// Protect the page
if (!CURRENT_USER_ID) {
    window.location.href = "login.html";
}


// -----------------------------
// Toast
// -----------------------------

function showToast(message) {
    const toast =
        document.getElementById("toast");

    if (!toast) return;

    toast.textContent = message;
    toast.classList.add("show");

    setTimeout(() => {
        toast.classList.remove("show");
    }, 2500);
}


// -----------------------------
// Format Currency
// -----------------------------

function formatCurrency(amount) {
    return `₹${Number(amount || 0).toFixed(2)}`;
}


// -----------------------------
// Load Month Summary
// -----------------------------

async function loadMonthSummary() {
    try {
        const summary =
            await apiGet(
                `/analytics/summary/${CURRENT_USER_ID}`
            );

        document.getElementById(
            "income-text"
        ).textContent =
            formatCurrency(summary.totalIncome);

        document.getElementById(
            "expense-text"
        ).textContent =
            formatCurrency(summary.totalExpenses);

        document.getElementById(
            "balance-text"
        ).textContent =
            formatCurrency(summary.balance);

    } catch (error) {

        console.error(
            "Failed to load month summary:",
            error
        );
    }
}


// -----------------------------
// Load Budgets
// -----------------------------

async function loadBudgets() {
    try {
        const response =
            await apiGet(
                `/budgets/status/${CURRENT_USER_ID}`
            );

        const budgets =
            response.budgets || response || [];

        const listBody =
            document.getElementById(
                "budget-list-body"
            );

        if (listBody) {
            listBody.innerHTML = "";
        }

        if (!budgets || budgets.length === 0) {

            // Overview
            document.getElementById(
                "total-monthly-budget"
            ).textContent = "₹0.00";

            document.getElementById(
                "monthly-budget-spent"
            ).textContent = "₹0.00";

            document.getElementById(
                "monthly-budget-remaining"
            ).textContent = "₹0.00";

            document.getElementById(
                "monthly-budget-status"
            ).textContent = "No Budget";

            document.getElementById(
                "monthly-budget-status"
            ).className =
                "budget-status budget-status-safe";

            document.getElementById(
                "budget-progress-bar"
            ).style.width = "0%";

            document.getElementById(
                "budget-empty-state"
            ).style.display = "block";

            document.getElementById(
                "budget-details"
            ).style.display = "none";


            // History
            if (listBody) {
                listBody.innerHTML = `
                    <tr>
                        <td
                            colspan="6"
                            class="empty-state">
                            No monthly budgets found.
                        </td>
                    </tr>
                `;
            }

            return;
        }


        /*
         * ----------------------------------------
         * Sort budgets by month - newest first
         * ----------------------------------------
         */

        budgets.sort(
            (a, b) =>
                new Date(b.month) -
                new Date(a.month)
        );


        /*
         * ----------------------------------------
         * Latest budget for overview
         * ----------------------------------------
         */

        const latestBudget =
            budgets[0];

        const budgetAmount =
            Number(
                latestBudget.budgetAmount || 0
            );

        const spentAmount =
            Number(
                latestBudget.spentAmount || 0
            );

        const remainingAmount =
            Number(
                latestBudget.remainingAmount || 0
            );

        const spendingPercentage =
            budgetAmount > 0
                ? (spentAmount / budgetAmount) * 100
                : 0;


        let statusText;
        let statusClass;
        let progressClass;


        if (spendingPercentage >= 100) {

            statusText =
                "Over Budget";

            statusClass =
                "budget-status-over";

            progressClass =
                "budget-progress-over";

        } else if (spendingPercentage >= 80) {

            statusText =
                "Close to Budget";

            statusClass =
                "budget-status-close";

            progressClass =
                "budget-progress-close";

        } else {

            statusText =
                "Within Budget";

            statusClass =
                "budget-status-safe";

            progressClass =
                "budget-progress-safe";
        }


        /*
         * ----------------------------------------
         * Update overview
         * ----------------------------------------
         */

        document.getElementById(
            "total-monthly-budget"
        ).textContent =
            formatCurrency(
                budgetAmount
            );

        document.getElementById(
            "monthly-budget-spent"
        ).textContent =
            formatCurrency(
                spentAmount
            );

        document.getElementById(
            "monthly-budget-remaining"
        ).textContent =
            formatCurrency(
                remainingAmount
            );


        const statusElement =
            document.getElementById(
                "monthly-budget-status"
            );

        statusElement.textContent =
            statusText;

        statusElement.className =
            `budget-status ${statusClass}`;


        /*
         * ----------------------------------------
         * Progress bar
         * ----------------------------------------
         */

        const progressBar =
            document.getElementById(
                "budget-progress-bar"
            );

        const progressPercentage =
            Math.min(
                Math.max(
                    spendingPercentage,
                    0
                ),
                100
            );

        progressBar.style.width =
            `${progressPercentage}%`;

        progressBar.className =
            `budget-progress-bar ${progressClass}`;


        /*
         * ----------------------------------------
         * Overview details
         * ----------------------------------------
         */

        document.getElementById(
            "budget-detail-month"
        ).textContent =
            formatBudgetMonth(
                latestBudget.month
            );

        document.getElementById(
            "budget-detail-percentage"
        ).textContent =
            `${spendingPercentage.toFixed(1)}%`;

        document.getElementById(
            "budget-empty-state"
        ).style.display = "none";

        document.getElementById(
            "budget-details"
        ).style.display = "grid";


        /*
         * ----------------------------------------
         * Render ALL budget history
         * ----------------------------------------
         */

        if (!listBody) {
            return;
        }


        budgets.forEach(
            budget => {

                const amount =
                    Number(
                        budget.budgetAmount || 0
                    );

                const spent =
                    Number(
                        budget.spentAmount || 0
                    );

                const remaining =
                    Number(
                        budget.remainingAmount || 0
                    );

                const percentage =
                    amount > 0
                        ? (spent / amount) * 100
                        : 0;


                let rowStatus;
                let rowStatusClass;


                if (percentage >= 100) {

                    rowStatus =
                        "Over Budget";

                    rowStatusClass =
                        "budget-status-over";

                } else if (percentage >= 80) {

                    rowStatus =
                        "Close to Budget";

                    rowStatusClass =
                        "budget-status-close";

                } else {

                    rowStatus =
                        "Within Budget";

                    rowStatusClass =
                        "budget-status-safe";
                }


                const row =
                    document.createElement("tr");


                row.innerHTML = `
                    <td>
                        ${formatBudgetMonth(
                            budget.month
                        )}
                    </td>

                    <td>
                        ${formatCurrency(
                            amount
                        )}
                    </td>

                    <td>
                        ${formatCurrency(
                            spent
                        )}
                    </td>

                    <td>
                        ${formatCurrency(
                            remaining
                        )}
                    </td>

                    <td>
                        <span
                            class="budget-status ${rowStatusClass}">
                            ${rowStatus}
                        </span>
                    </td>

                    <td>
                        <button
                            type="button"
                            class="secondary-btn"
                            onclick="editBudget(${budget.budgetId})">
                            Edit
                        </button>

                        <button
                            type="button"
                            class="secondary-btn"
                            onclick="deleteBudget(${budget.budgetId})">
                            Delete
                        </button>
                    </td>
                `;


                listBody.appendChild(row);
            }
        );

    } catch (error) {

        console.error(
            "Failed to load budgets:",
            error
        );

        showToast(
            "Failed to load budget information."
        );
    }
}
function formatBudgetMonth(month) {

    if (!month) {
        return "-";
    }

    const parts =
        month.split("-");

    if (parts.length < 2) {
        return month;
    }

    const year =
        Number(parts[0]);

    const monthNumber =
        Number(parts[1]);

    const date =
        new Date(
            year,
            monthNumber - 1,
            1
        );

    return date.toLocaleDateString(
        "en-IN",
        {
            month: "long",
            year: "numeric"
        }
    );
}


// -----------------------------
// Add / Update Budget
// -----------------------------
// -----------------------------
// Populate Budget Months
// -----------------------------

function populateBudgetMonths() {

    const monthSelect =
        document.getElementById("budget-month");

    if (!monthSelect) return;


    // Keep the placeholder
    monthSelect.innerHTML = `
        <option value="">
            Select month
        </option>
    `;


    const today = new Date();

    const currentYear =
        today.getFullYear();

    const currentMonth =
        today.getMonth();


    /*
     * Show the current month plus
     * the next 11 months.
     *
     * Example:
     * September 2026
     * October 2026
     * ...
     * August 2027
     */

    for (let i = 0; i < 12; i++) {

        const date =
            new Date(
                currentYear,
                currentMonth + i,
                1
            );

        const year =
            date.getFullYear();

        const monthNumber =
            date.getMonth() + 1;

        const value =
            `${year}-${String(monthNumber).padStart(2, "0")}`;

        const label =
            date.toLocaleDateString(
                "en-IN",
                {
                    month: "long",
                    year: "numeric"
                }
            );


        const option =
            document.createElement("option");

        option.value = value;
        option.textContent = label;

        monthSelect.appendChild(option);
    }
}
async function saveBudget(event) {

    event.preventDefault();


    const amount =
        Number(
            document.getElementById(
                "budget-amount"
            ).value
        );


    const month =
        document.getElementById(
            "budget-month"
        ).value;


    if (
        amount <= 0 ||
        !month
    ) {

        showToast(
            "Please enter a valid monthly budget."
        );

        return;
    }


    /*
     * The month select returns:
     *
     * YYYY-MM
     *
     * MySQL DATE column expects:
     *
     * YYYY-MM-01
     */

    const monthDate =
        `${month}-01`;


    try {

        if (editingBudgetId) {

            await apiPut(
                `/budgets/${editingBudgetId}`,
                {
                    amount: amount,
                    month: monthDate
                }
            );

            showToast(
                "Monthly budget updated successfully."
            );

        } else {

            await apiPost(
                "/budgets",
                {
                    amount: amount,
                    month: monthDate
                }
            );

            showToast(
                "Monthly budget created successfully."
            );
        }


        resetBudgetForm();

        await loadBudgets();

    } catch (error) {

        console.error(
            "Failed to save budget:",
            error
        );

        showToast(
            error.message ||
            "Failed to save budget."
        );
    }
}


// -----------------------------
// Edit Budget
// -----------------------------

async function editBudget(budgetId) {

    try {

        const response =
            await apiGet(
                `/budgets/${CURRENT_USER_ID}`
            );

        const budgets =
            response.budgets || [];

        const budget =
            budgets.find(
                item =>
                    item.id === budgetId
            );


        if (!budget) {

            showToast(
                "Budget not found."
            );

            return;
        }


        editingBudgetId =
            budgetId;


        document.getElementById(
            "budget-form-title"
        ).textContent =
            "Edit Monthly Budget";


        document.getElementById(
            "budget-submit-btn"
        ).textContent =
            "Update Budget";


        document.getElementById(
            "budget-amount"
        ).value =
            budget.amount;


        /*
         * Convert:
         *
         * 2026-09-01
         *
         * to:
         *
         * 2026-09
         */

        document.getElementById(
            "budget-month"
        ).value =
            budget.month.substring(0, 7);


        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    } catch (error) {

        console.error(
            "Failed to load budget:",
            error
        );

        showToast(
            "Failed to load budget."
        );
    }
}


// -----------------------------
// Delete Budget
// -----------------------------

async function deleteBudget(budgetId) {

    const confirmed =
        confirm(
            "Are you sure you want to delete this monthly budget?"
        );

    if (!confirmed) return;


    try {

        await apiDelete(
            `/budgets/${budgetId}`
        );

        showToast(
            "Monthly budget deleted successfully."
        );

        await loadBudgets();

    } catch (error) {

        console.error(
            "Failed to delete budget:",
            error
        );

        showToast(
            error.message ||
            "Failed to delete budget."
        );
    }
}


// -----------------------------
// Reset Form
// -----------------------------

function resetBudgetForm() {

    editingBudgetId = null;


    document.getElementById(
        "budget-form"
    ).reset();


    document.getElementById(
        "budget-form-title"
    ).textContent =
        "Add Monthly Budget";


    document.getElementById(
        "budget-submit-btn"
    ).textContent =
        "Save Budget";
}


// -----------------------------
// Logout
// -----------------------------

function setupLogout() {

    const logoutButton =
        document.getElementById(
            "logout-btn"
        );

    if (!logoutButton) return;


    logoutButton.addEventListener(
        "click",
        async () => {

            try {

                await apiPost(
                    "/users/logout",
                    {}
                );

            } catch (error) {

                console.error(
                    "Logout request failed:",
                    error
                );
            }


            localStorage.removeItem(
                "userId"
            );

            localStorage.removeItem(
                "username"
            );

            localStorage.removeItem(
                "authToken"
            );


            window.location.href =
                "login.html";
        }
    );
}


// -----------------------------
// Add Budget Button
// -----------------------------

function setupAddBudgetButton() {

    const button =
        document.getElementById(
            "add-budget-btn"
        );

    if (!button) return;


    button.addEventListener(
        "click",
        () => {

            resetBudgetForm();


            document.getElementById(
                "budget-amount"
            ).focus();


            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        }
    );
}


// -----------------------------
// Cancel Button
// -----------------------------

function setupCancelButton() {

    const button =
        document.getElementById(
            "budget-cancel-btn"
        );

    if (!button) return;


    button.addEventListener(
        "click",
        resetBudgetForm
    );
}


// -----------------------------
// Page Initialization
// -----------------------------

document.addEventListener(
    "DOMContentLoaded",
    async () => {

        setupLogout();

        setupAddBudgetButton();

        setupCancelButton();
         populateBudgetMonths();

        const budgetForm =
            document.getElementById(
                "budget-form"
            );

        if (budgetForm) {

            budgetForm.addEventListener(
                "submit",
                saveBudget
            );
        }


        await loadMonthSummary();

        await loadBudgets();
    }
);